# Docopt testcases

These are the testcases that are retrieved from 
[docopt](https://github.com/docopt/docopt).

The R testcases are generated from this file.

