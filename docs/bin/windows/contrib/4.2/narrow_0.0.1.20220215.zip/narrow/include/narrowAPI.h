
// API header for narrow

#ifndef _NARROW_API_H
#define _NARROW_API_H

//#include <narrow.h>

#include <Rconfig.h>
#include <R_ext/Rdynload.h>

#ifdef HAVE_VISIBILITY_ATTRIBUTE
  # define attribute_hidden __attribute__ ((visibility ("hidden")))
#else
  # define attribute_hidden
#endif

#ifdef __cplusplus
extern "C" {
#endif

  SEXP attribute_hidden narrow_c_array_from_sexp(SEXP buffers_sexp, SEXP length_sexp,
                                                 SEXP null_count_sexp, SEXP int64_sexp,
                                                 SEXP children_sexp, SEXP dictionary_xptr) {
    static SEXP(*fun)(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP) =
      (SEXP(*)(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP)) R_GetCCallable("narrow","narrow_c_array_from_sexp");
    return fun(buffers_sexp, length_sexp, null_count_sexp, int64_sexp, children_sexp, dictionary_xptr);
  }

  SEXP attribute_hidden narrow_c_array_info(SEXP array_data_xptr) {
    static SEXP(*fun)(SEXP) = (SEXP(*)(SEXP)) R_GetCCallable("narrow","narrow_c_array_info");
    return fun(array_data_xptr);
  }

  // ....

  SEXP attribute_hidden narrow_c_allocate_schema() {
    static SEXP(*fun)() = (SEXP(*)()) R_GetCCallable("narrow","narrow_c_allocate_schema");
    return fun();
  }

  SEXP attribute_hidden narrow_c_allocate_array_data() {
    static SEXP(*fun)() = (SEXP(*)()) R_GetCCallable("narrow","narrow_c_allocate_array_data");
    return fun();
  }

  SEXP attribute_hidden narrow_c_schema_xptr_new(SEXP format_sexp, SEXP name_sexp,
                                                 SEXP metadata_sexp, SEXP flags_sexp,
                                                 SEXP children_sexp, SEXP dictionary_xptr) {
    static SEXP(*fun)(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP) =
      (SEXP(*)(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP)) R_GetCCallable("narrow","narrow_c_schema_xptr_new");
    return fun(format_sexp, name_sexp, metadata_sexp, flags_sexp, children_sexp, dictionary_xptr);
  }


#ifdef __cplusplus
}
#endif

#endif /* !_NARROW_API_H */
