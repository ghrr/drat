
#include "narrow/narrow.c"
