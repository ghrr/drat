library(testthat)
library(narrow)

test_check("narrow")
