
#include "narrow/narrow-cpp.cc"
