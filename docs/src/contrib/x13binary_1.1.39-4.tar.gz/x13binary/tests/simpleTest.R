x13binary::checkX13binary()


library(x13binary)

checkX13binary()
