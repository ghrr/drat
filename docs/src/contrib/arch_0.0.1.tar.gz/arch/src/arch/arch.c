
#include "status.c"
#include "schema.c"
#include "array-data.c"
#include "array-init.c"
#include "array-parse-format.c"
#include "array-alloc.c"
#include "array-copy.c"
#include "array-validate.c"
