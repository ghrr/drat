library(testthat)
library(arch)

test_check("arch")
