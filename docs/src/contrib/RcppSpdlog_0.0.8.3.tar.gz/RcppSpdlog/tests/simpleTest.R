
## super-simple
## TODO: proper tests of a compilation or two

stopifnot(system.file("include", "spdlog", "spdlog.h", package="RcppSpdlog") != "")
