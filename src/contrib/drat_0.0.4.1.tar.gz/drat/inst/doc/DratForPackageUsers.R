## ---- eval=FALSE---------------------------------------------------------
#  drat::addRepo("eddelbuettel")

## ---- eval=FALSE---------------------------------------------------------
#  drat::addRepo(c("eddelbuettel", "RcppCore", "ghrr"))

