
library(x13binary)

checkX13binary()
