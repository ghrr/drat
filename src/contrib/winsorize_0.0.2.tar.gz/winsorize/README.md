## winsorize [![Build Status](https://travis-ci.org/eddelbuettel/winsorize.png)](https://travis-ci.org/eddelbuettel/winsorize) [![License](http://img.shields.io/badge/license-GPL%20%28%3E=%202%29-brightgreen.svg?style=flat)](http://www.gnu.org/licenses/gpl-2.0.html)

Outlier removal by winsorization

### Status

The package is spun-off the excellent
[robustHD](http://cran.rstudio.com/package=robustHD) package in order to
provide a smaller winsorization package with fewer dependencies.

### Authors

Andreas Alfons and Dirk Eddelbuettel 

### License

GPL (>= 2)

