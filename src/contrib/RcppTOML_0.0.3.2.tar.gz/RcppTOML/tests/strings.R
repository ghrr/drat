
print(RcppTOML::tomlparse("strings.toml"))
