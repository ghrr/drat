  ------ -----------------
  NEWS   R Documentation
  ------ -----------------

News for Package <span class="pkg">Rblpapi</span>
-------------------------------------------------

### Changes in Rblpapi version 0.3.5 (2016-10-25)

-   Add new function `getPortfolio` to retrieve portfolio data via `bds`
    (John in [\#176](https://github.com/Rblp/Rblpapi/pull/176))

-   Extend `getTicks()` to (optionally) return non-numeric data as part
    of `data.frame` or `data.table` (Dirk in
    [\#200](https://github.com/Rblp/Rblpapi/pull/200))

-   Similarly extend `getMultipleTicks` (Dirk in
    [\#202](https://github.com/Rblp/Rblpapi/pull/202))

-   Correct statement on timestamp for `getBars` (Closes issue
    [\#192](https://github.com/Rblp/Rblpapi/issues/192))

-   Minor edits to a few files in order to either please
    `R(-devel) CMD check --as-cran`, or update documentation

### Changes in Rblpapi version 0.3.4 (2016-05-08)

-   On startup, the API versions of both the headers and the runtime are
    displayed (PR [\#161](https://github.com/Rblp/Rblpapi/pull/161) and
    [\#165](https://github.com/Rblp/Rblpapi/pull/165)).

-   Documentation about extended futures roll notation was added to the
    `bdh` manul page.

-   Additional examples for overrides where added to `bdh` (PR
    [\#158](https://github.com/Rblp/Rblpapi/pull/158)).

-   Internal code changes make retrieval of data in ‘unusual’ variable
    types more robust (PRs
    [\#157](https://github.com/Rblp/Rblpapi/pull/157) and
    [\#153](https://github.com/Rblp/Rblpapi/pull/153))

-   General improvements and fixes to documentation (PR
    [\#156](https://github.com/Rblp/Rblpapi/pull/156))

-   The `bdp` function now also supports an option `verbose` (PR
    [\#149](https://github.com/Rblp/Rblpapi/pull/149)).

-   The internal header `Rblpapi_types.h` was renamed from a lower-cased
    variant to conform with Rcpp Attributes best practices (PR
    [\#145](https://github.com/Rblp/Rblpapi/pull/145)).

### Changes in Rblpapi version 0.3.3 (2016-03-14)

-   `configure` adds a missing `method="libcurl"` options (PR
    [\#109](https://github.com/Rblp/Rblpapi/pull/109) by Martin Bel).

-   New function `bsrch()` adds basic search functionality (PR
    [\#111](https://github.com/Rblp/Rblpapi/pull/111) by Morgan Williams
    fixing ticket [\#82](https://github.com/Rblp/Rblpapi/issues/82)).

-   The licensing status of the Rblpapi source package was clarified (PR
    [\#119](https://github.com/Rblp/Rblpapi/pull/119)).

-   The `bds()` help page now shows an example using an `overrides`
    argument (PR [\#121](https://github.com/Rblp/Rblpapi/pull/121)).

-   A new function `fieldInfo` was added, and field information is used
    in `bdh` and `bdp` (PRs
    [\#122](https://github.com/Rblp/Rblpapi/pull/122),
    [\#123](https://github.com/Rblp/Rblpapi/pull/123),
    [\#125](https://github.com/Rblp/Rblpapi/pull/125), and
    [\#127](https://github.com/Rblp/Rblpapi/pull/127)).

-   The `bdp` function now checks the order (PR
    [\#126](https://github.com/Rblp/Rblpapi/pull/126)).

-   Unit testing was added (PRs
    [\#129](https://github.com/Rblp/Rblpapi/pull/129) and
    [\#131](https://github.com/Rblp/Rblpapi/pull/131)).

-   Data retrieval is now smarter about the types returned from
    Bloomberg (PR [\#132](https://github.com/Rblp/Rblpapi/pull/132) and
    [\#133](https://github.com/Rblp/Rblpapi/pull/133); and
    [\#141](https://github.com/Rblp/Rblpapi/pull/141) and
    [\#142](https://github.com/Rblp/Rblpapi/pull/142)).

-   The `bdh` and `bds` functions now support an option `verbose` (PRs
    [\#138](https://github.com/Rblp/Rblpapi/pull/138)).

### Changes in Rblpapi version 0.3.2 (2015-12-06)

-   A new `subscribe()` function supports live data subscription for a
    set of tickers and fields
    ([\#88](https://github.com/Rblp/Rblpapi/pull/88)).

-   In the `beqs()` example the correct date format is used (PR
    [\#85](https://github.com/Rblp/Rblpapi/pull/85) by Rademeyer).

-   Both `getTicks()` and `getBars()` now check the start and end times
    for proper `Datetime` class.

-   The `getBars()` function now also return the ‘value traded’ (request
    of [\#89](https://github.com/Rblp/Rblpapi/issues/89)).

-   An error in the documentation for `bdh` was corrected (PR
    [\#93](https://github.com/Rblp/Rblpapi/pull/93) by Rademeyer closing
    [\#85](https://github.com/Rblp/Rblpapi/issues/85)).

-   The `beqs()` function is now more robust with respect to empty
    return columns (PR [\#100](https://github.com/Rblp/Rblpapi/pull/100)
    by Rademeyer fixing ticket
    [\#99](https://github.com/Rblp/Rblpapi/issues/99)).

-   The `getBars()` function now uses a single (named) vector `options`
    to pass optional values to the underlying function (PR
    [\#105](https://github.com/Rblp/Rblpapi/pull/105) updating PR
    [\#48](https://github.com/Rblp/Rblpapi/pull/48) and fixing
    [\#47](https://github.com/Rblp/Rblpapi/issues/47)).

-   When R is built with libcurl support, it used to download the
    build-time library and headers; otherwise `curl` is used. This
    avoids an issue on OS X where `curl` is insufficient.

### Changes in Rblpapi version 0.3.1 (2015-10-19)

-   Added `beqs()` to run Bloomberg Equity Screen Search, based on
    initial PR [\#79](https://github.com/Rblp/Rblpapi/pull/79) by
    Rademeyer Vermaak, reworked in PRs
    [\#83](https://github.com/Rblp/Rblpapi/pull/83) and
    [\#84](https://github.com/Rblp/Rblpapi/pull/84) by Dirk; closes
    tickets [\#63](https://github.com/Rblp/Rblpapi/issues/63) and
    [\#80](https://github.com/Rblp/Rblpapi/issues/80).

-   Bloomberg header and library files are now cached locally instead of
    being re-downloaded for every build (PR
    [\#78](https://github.com/Rblp/Rblpapi/pull/78) by Dirk addressing
    issue [\#65](https://github.com/Rblp/Rblpapi/pull/65)).

-   For multiple ticks, time-stamps are unique-yfied before merging (PR
    [\#77](https://github.com/Rblp/Rblpapi/pull/77) by Dirk addressing
    issue [\#76](https://github.com/Rblp/Rblpapi/issues/76)).

-   A compiler warning under new g++ versions is now suppressed (PR
    [\#69](https://github.com/Rblp/Rblpapi/pull/69) by John, fixing
    [\#68](https://github.com/Rblp/Rblpapi/issues/68)).

### Changes in Rblpapi version 0.3.0 (2015-08-13)

-   First CRAN Release

-   Source and binary builds supported on Linux, Windows and OS X

-   Build procedures rewritten so that required headers and libraries
    are downloaded during installation from corresponding GitHub repo
    [<span class="pkg">Rblp/blp</span>](https://github.com/Rblp/blp)
    which contains custom tarballs derived from the corresponding
    upstream releases at <http://www.bloomberglabs.com/api>.


