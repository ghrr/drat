Files from https://github.com/plokhotnyuk/jsoniter-scala/tree/master/jsoniter-scala-benchmark/src/main/resources/com/github/plokhotnyuk/jsoniter_scala/benchmark

See issue "Lower performance on small files":
https://github.com/lemire/simdjson/issues/70
